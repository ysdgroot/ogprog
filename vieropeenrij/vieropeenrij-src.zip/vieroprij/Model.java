package vieroprij;

import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulate the game rules and the current game state.
 * Allow clients to subscribe to important model changes.
 * Notify listeners when changes to the model occur.
 */
public class Model {

    /*
     * If a new move causes the game to end then all listeners should be notified of this fact. You can use
     * {@link #notifyListeners} for this.
     */
    private void checkGameOver() {
        // TODO (step 3): implement this.
    }

    /**
     * Check if a new disc can be inserted in the current column. Note that this is only
     * a check and the disc should not yet be played. See also {@link #playMove}
     * @param column
     * @return true if and only if a move in this column is allowed.
     */
    public boolean isPlayableMove(int column) {
        // TODO: Check if this move is playable.

        // TODO (step 3) No moves are allowed when the game is over.
        return true;
    }

    /**
     * Compute the final destination row of a candidate move.
     * @param column The column in which a disc is going to be played.
     * @return The row where the disc will eventually be stored.
     */
    public int moveDestination(int column) {
        // TODO: implement this method properly.
        return Config.NUM_ROWS - 1;
    }

    /**
     * A new move is committed to the model when the move animation has ended.
     * Commit the insertion of a new disc in a given column and update game state.
     * @param column The column in which a new disc has been inserted.
     */
    public void playMove(int column) {
        // TODO: Verify the following preconditions:
        // assert (isGameOver() == false);
        // assert (isPlayableMove(column) == true);
        
        // TODO: Update the model to reflect the new move.
        
        // TODO (step 3): Also check for termination conditions.
        
        // TODO (step 3): Maybe notify listeners about important model changes.
    }


    // The code below manages listeners. You can use these methods, but do not
    // modify the code
    //

    // List of all registered listeners
    List<GameOverListener> listeners = new ArrayList<>();

    /**
     * Registers a listener which should be notified whenever the game is finished
     */
    public void addListener (GameOverListener listener) {
        listeners.add(listener);
    }

    /**
     * Notify all registered listeners that the game is finished
     * @param winner indicates whether there was a winner (if true) or the game simply ended
     *               because the board is full
     */
    public void notifyListeners (boolean winner) {
        for (GameOverListener listener : listeners) {
            listener.gameOver(winner);
        }
    }

}
